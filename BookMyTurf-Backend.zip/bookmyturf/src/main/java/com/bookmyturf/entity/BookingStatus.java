package com.bookmyturf.entity;

public enum BookingStatus {
    PENDING, CONFIRMED, CANCELLED, COMPLETED
}

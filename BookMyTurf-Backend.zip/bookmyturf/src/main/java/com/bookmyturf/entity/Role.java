package com.bookmyturf.entity;

public enum Role {
    USER, OWNER, ADMIN
}

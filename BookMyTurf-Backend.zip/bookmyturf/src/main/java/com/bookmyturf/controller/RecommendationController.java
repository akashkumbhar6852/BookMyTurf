package com.bookmyturf.controller;

import com.bookmyturf.dto.RecommendationRequest;
import com.bookmyturf.dto.RecommendationResponse;
import com.bookmyturf.service.RecommendationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/recommendations")
@RequiredArgsConstructor
public class RecommendationController {

    private final RecommendationService recommendationService;

    @PostMapping
    public ResponseEntity<Map<String, List<RecommendationResponse>>> recommend(@RequestBody RecommendationRequest request) {
        List<RecommendationResponse> recommendations = recommendationService.recommend(request);
        return ResponseEntity.ok(Map.of("recommendations", recommendations));
    }
}

package com.bookmyturf.controller;

import com.bookmyturf.dto.SlotRequest;
import com.bookmyturf.entity.Slot;
import com.bookmyturf.service.SlotService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/turfs/{turfId}/slots")
@RequiredArgsConstructor
public class SlotController {

    private final SlotService slotService;

    @PostMapping
    public ResponseEntity<Slot> createSlot(@PathVariable Long turfId, @Valid @RequestBody SlotRequest request) {
        return ResponseEntity.ok(slotService.createSlot(turfId, request));
    }

    @GetMapping
    public ResponseEntity<List<Slot>> getSlots(
            @PathVariable Long turfId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        if (date != null) {
            return ResponseEntity.ok(slotService.getSlotsForTurfOnDate(turfId, date));
        }
        return ResponseEntity.ok(slotService.getAvailableSlotsForTurf(turfId));
    }
}

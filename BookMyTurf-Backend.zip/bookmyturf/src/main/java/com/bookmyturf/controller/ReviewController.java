package com.bookmyturf.controller;

import com.bookmyturf.dto.ReviewRequest;
import com.bookmyturf.entity.Review;
import com.bookmyturf.service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    @PostMapping
    public ResponseEntity<Review> addReview(@Valid @RequestBody ReviewRequest request) {
        return ResponseEntity.ok(reviewService.addReview(request));
    }

    @GetMapping("/turf/{turfId}")
    public ResponseEntity<List<Review>> getReviewsForTurf(@PathVariable Long turfId) {
        return ResponseEntity.ok(reviewService.getReviewsForTurf(turfId));
    }
}

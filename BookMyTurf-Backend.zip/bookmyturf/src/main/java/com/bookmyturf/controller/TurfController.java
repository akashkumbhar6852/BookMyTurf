package com.bookmyturf.controller;

import com.bookmyturf.dto.TurfRequest;
import com.bookmyturf.entity.Turf;
import com.bookmyturf.service.TurfService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/turfs")
@RequiredArgsConstructor
public class TurfController {

    private final TurfService turfService;

    @PostMapping
    public ResponseEntity<Turf> createTurf(@Valid @RequestBody TurfRequest request) {
        return ResponseEntity.ok(turfService.createTurf(request));
    }

    @GetMapping
    public ResponseEntity<List<Turf>> getTurfs(
            @RequestParam(required = false) String sport,
            @RequestParam(required = false) String location) {
        if (sport != null || location != null) {
            return ResponseEntity.ok(turfService.searchTurfs(sport, location));
        }
        return ResponseEntity.ok(turfService.getAllTurfs());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Turf> getTurfById(@PathVariable Long id) {
        return ResponseEntity.ok(turfService.getTurfById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Turf> updateTurf(@PathVariable Long id, @Valid @RequestBody TurfRequest request) {
        return ResponseEntity.ok(turfService.updateTurf(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTurf(@PathVariable Long id) {
        turfService.deleteTurf(id);
        return ResponseEntity.noContent().build();
    }
}

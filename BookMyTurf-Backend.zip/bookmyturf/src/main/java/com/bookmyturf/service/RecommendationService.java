package com.bookmyturf.service;

import com.bookmyturf.dto.RecommendationRequest;
import com.bookmyturf.dto.RecommendationResponse;
import com.bookmyturf.entity.Slot;
import com.bookmyturf.entity.Turf;
import com.bookmyturf.repository.SlotRepository;
import com.bookmyturf.repository.TurfRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * Hybrid, rule-based recommendation engine:
 * Database filtering + user preferences + turf rating -> personalized ranking.
 * No external ML model required for the first working version; this can later
 * be swapped for a trained model or an LLM-backed scorer behind the same interface.
 */
@Service
@RequiredArgsConstructor
public class RecommendationService {

    private final TurfRepository turfRepository;
    private final SlotRepository slotRepository;

    public List<RecommendationResponse> recommend(RecommendationRequest request) {
        List<Turf> candidates = turfRepository.findAll();
        List<RecommendationResponse> results = new ArrayList<>();

        for (Turf turf : candidates) {
            if (request.getSport() != null && !turf.getSport().equalsIgnoreCase(request.getSport())) {
                continue;
            }

            List<Slot> slots = request.getDate() != null
                    ? slotRepository.findByTurfIdAndSlotDate(turf.getId(), request.getDate())
                    : slotRepository.findByTurfIdAndAvailableTrue(turf.getId());

            boolean hasAvailableSlot = slots.stream().anyMatch(Slot::isAvailable);
            if (!slots.isEmpty() && !hasAvailableSlot) {
                continue;
            }

            double score = 0;
            List<String> reasons = new ArrayList<>();

            // Sport already matched above (or no preference given)
            score += 25;
            reasons.add("matches your preferred sport");

            // Location match
            if (request.getLocation() != null) {
                if (turf.getLocation().equalsIgnoreCase(request.getLocation())) {
                    score += 20;
                    reasons.add("in your preferred location");
                } else if (turf.getLocation().toLowerCase().contains(request.getLocation().toLowerCase())) {
                    score += 12;
                    reasons.add("near your preferred location");
                }
            }

            // Budget match
            if (request.getBudget() != null) {
                if (turf.getPrice() <= request.getBudget()) {
                    double closeness = 1 - (request.getBudget() - turf.getPrice()) / Math.max(request.getBudget(), 1);
                    score += 20 * Math.min(1, Math.max(0.4, closeness));
                    reasons.add("within your budget");
                } else {
                    score -= 15;
                }
            }

            // Rating boost
            if (turf.getRating() != null) {
                score += turf.getRating() * 4; // up to +20 for a 5-star turf
                if (turf.getRating() >= 4.0) {
                    reasons.add("highly rated by other players");
                }
            }

            // Preferred time match
            if (request.getPreferredTime() != null && !slots.isEmpty()) {
                boolean timeMatch = slots.stream().anyMatch(slot ->
                        !request.getPreferredTime().isBefore(slot.getStartTime())
                                && request.getPreferredTime().isBefore(slot.getEndTime()));
                if (timeMatch) {
                    score += 15;
                    reasons.add("available at your preferred time");
                }
            }

            score = Math.max(0, Math.min(100, score));

            String reason = String.join(", ", reasons);
            reason = reason.isEmpty()
                    ? "Matches your search criteria."
                    : Character.toUpperCase(reason.charAt(0)) + reason.substring(1) + ".";

            results.add(RecommendationResponse.builder()
                    .turfId(turf.getId())
                    .turf(turf.getName())
                    .matchScore(Math.round(score * 10.0) / 10.0)
                    .reason(reason)
                    .build());
        }

        results.sort(Comparator.comparingDouble(RecommendationResponse::getMatchScore).reversed());
        return results;
    }
}

package com.bookmyturf.service;

import com.bookmyturf.dto.SlotRequest;
import com.bookmyturf.entity.Slot;
import com.bookmyturf.entity.Turf;
import com.bookmyturf.exception.BadRequestException;
import com.bookmyturf.exception.ResourceNotFoundException;
import com.bookmyturf.repository.SlotRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SlotService {

    private final SlotRepository slotRepository;
    private final TurfService turfService;

    public Slot createSlot(Long turfId, SlotRequest request) {
        Turf turf = turfService.getTurfById(turfId);

        if (!request.getEndTime().isAfter(request.getStartTime())) {
            throw new BadRequestException("End time must be after start time");
        }

        Slot slot = Slot.builder()
                .turf(turf)
                .slotDate(request.getSlotDate())
                .startTime(request.getStartTime())
                .endTime(request.getEndTime())
                .available(true)
                .build();

        return slotRepository.save(slot);
    }

    public List<Slot> getAvailableSlotsForTurf(Long turfId) {
        return slotRepository.findByTurfIdAndAvailableTrue(turfId);
    }

    public List<Slot> getSlotsForTurfOnDate(Long turfId, LocalDate date) {
        return slotRepository.findByTurfIdAndSlotDate(turfId, date);
    }

    public Slot getSlotById(Long id) {
        return slotRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Slot not found with id: " + id));
    }

    public void markSlotUnavailable(Long slotId) {
        Slot slot = getSlotById(slotId);
        slot.setAvailable(false);
        slotRepository.save(slot);
    }

    public void markSlotAvailable(Long slotId) {
        Slot slot = getSlotById(slotId);
        slot.setAvailable(true);
        slotRepository.save(slot);
    }
}

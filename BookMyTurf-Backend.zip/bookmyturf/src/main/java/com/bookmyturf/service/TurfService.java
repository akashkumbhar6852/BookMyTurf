package com.bookmyturf.service;

import com.bookmyturf.dto.TurfRequest;
import com.bookmyturf.entity.Turf;
import com.bookmyturf.entity.User;
import com.bookmyturf.exception.ResourceNotFoundException;
import com.bookmyturf.repository.TurfRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TurfService {

    private final TurfRepository turfRepository;
    private final UserService userService;

    public Turf createTurf(TurfRequest request) {
        User owner = userService.getCurrentUser();

        Turf turf = Turf.builder()
                .name(request.getName())
                .location(request.getLocation())
                .sport(request.getSport())
                .price(request.getPrice())
                .description(request.getDescription())
                .rating(0.0)
                .owner(owner)
                .build();

        return turfRepository.save(turf);
    }

    public List<Turf> getAllTurfs() {
        return turfRepository.findAll();
    }

    public Turf getTurfById(Long id) {
        return turfRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Turf not found with id: " + id));
    }

    public List<Turf> searchTurfs(String sport, String location) {
        if (sport != null && location != null) {
            return turfRepository.findBySportIgnoreCaseAndLocationIgnoreCaseContaining(sport, location);
        } else if (location != null) {
            return turfRepository.findByLocationIgnoreCaseContaining(location);
        } else if (sport != null) {
            return turfRepository.findBySportIgnoreCase(sport);
        }
        return turfRepository.findAll();
    }

    public Turf updateTurf(Long id, TurfRequest request) {
        Turf turf = getTurfById(id);
        turf.setName(request.getName());
        turf.setLocation(request.getLocation());
        turf.setSport(request.getSport());
        turf.setPrice(request.getPrice());
        turf.setDescription(request.getDescription());
        return turfRepository.save(turf);
    }

    public void deleteTurf(Long id) {
        Turf turf = getTurfById(id);
        turfRepository.delete(turf);
    }

    public void updateTurfRating(Long turfId, double newRating) {
        Turf turf = getTurfById(turfId);
        turf.setRating(newRating);
        turfRepository.save(turf);
    }
}

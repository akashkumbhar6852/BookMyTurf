package com.bookmyturf.service;

import com.bookmyturf.dto.BookingRequest;
import com.bookmyturf.entity.Booking;
import com.bookmyturf.entity.BookingStatus;
import com.bookmyturf.entity.Slot;
import com.bookmyturf.entity.Turf;
import com.bookmyturf.entity.User;
import com.bookmyturf.exception.BadRequestException;
import com.bookmyturf.exception.ResourceNotFoundException;
import com.bookmyturf.repository.BookingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final BookingRepository bookingRepository;
    private final UserService userService;
    private final TurfService turfService;
    private final SlotService slotService;

    public Booking createBooking(BookingRequest request) {
        User user = userService.getCurrentUser();
        Turf turf = turfService.getTurfById(request.getTurfId());
        Slot slot = slotService.getSlotById(request.getSlotId());

        if (!slot.isAvailable()) {
            throw new BadRequestException("Selected slot is no longer available");
        }

        if (!slot.getTurf().getId().equals(turf.getId())) {
            throw new BadRequestException("Slot does not belong to the specified turf");
        }

        Booking booking = Booking.builder()
                .user(user)
                .turf(turf)
                .slot(slot)
                .status(BookingStatus.CONFIRMED)
                .build();

        Booking saved = bookingRepository.save(booking);
        slotService.markSlotUnavailable(slot.getId());

        return saved;
    }

    public List<Booking> getMyBookings() {
        User user = userService.getCurrentUser();
        return bookingRepository.findByUserId(user.getId());
    }

    public Booking getBookingById(Long id) {
        return bookingRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Booking not found with id: " + id));
    }

    public Booking cancelBooking(Long id) {
        Booking booking = getBookingById(id);
        User currentUser = userService.getCurrentUser();

        if (!booking.getUser().getId().equals(currentUser.getId())) {
            throw new BadRequestException("You are not allowed to cancel this booking");
        }

        if (booking.getStatus() == BookingStatus.CANCELLED) {
            throw new BadRequestException("Booking is already cancelled");
        }

        booking.setStatus(BookingStatus.CANCELLED);
        slotService.markSlotAvailable(booking.getSlot().getId());

        return bookingRepository.save(booking);
    }
}

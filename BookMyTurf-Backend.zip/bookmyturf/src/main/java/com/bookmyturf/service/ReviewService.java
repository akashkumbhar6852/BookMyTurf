package com.bookmyturf.service;

import com.bookmyturf.dto.ReviewRequest;
import com.bookmyturf.entity.Review;
import com.bookmyturf.entity.Turf;
import com.bookmyturf.entity.User;
import com.bookmyturf.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final UserService userService;
    private final TurfService turfService;

    public Review addReview(ReviewRequest request) {
        User user = userService.getCurrentUser();
        Turf turf = turfService.getTurfById(request.getTurfId());

        Review review = Review.builder()
                .user(user)
                .turf(turf)
                .rating(request.getRating())
                .comment(request.getComment())
                .build();

        Review saved = reviewRepository.save(review);

        recalculateTurfRating(turf.getId());

        return saved;
    }

    public List<Review> getReviewsForTurf(Long turfId) {
        return reviewRepository.findByTurfId(turfId);
    }

    private void recalculateTurfRating(Long turfId) {
        List<Review> reviews = reviewRepository.findByTurfId(turfId);
        double average = reviews.stream()
                .mapToInt(Review::getRating)
                .average()
                .orElse(0.0);
        turfService.updateTurfRating(turfId, Math.round(average * 10.0) / 10.0);
    }
}

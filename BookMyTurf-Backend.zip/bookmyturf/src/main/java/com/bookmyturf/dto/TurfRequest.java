package com.bookmyturf.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class TurfRequest {

    @NotBlank
    private String name;

    @NotBlank
    private String location;

    @NotBlank
    private String sport;

    @NotNull
    @Positive
    private Double price;

    private String description;
}

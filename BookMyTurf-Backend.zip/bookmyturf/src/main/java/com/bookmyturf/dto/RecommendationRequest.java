package com.bookmyturf.dto;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class RecommendationRequest {
    private String sport;
    private String location;
    private Double budget;
    private Integer players;
    private LocalDate date;
    private LocalTime preferredTime;
}

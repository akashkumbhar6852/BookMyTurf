package com.bookmyturf.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class BookingRequest {

    @NotNull
    private Long turfId;

    @NotNull
    private Long slotId;
}

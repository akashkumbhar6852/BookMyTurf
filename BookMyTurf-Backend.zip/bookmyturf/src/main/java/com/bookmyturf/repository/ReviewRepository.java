package com.bookmyturf.repository;

import com.bookmyturf.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ReviewRepository extends JpaRepository<Review, Long> {
    List<Review> findByTurfId(Long turfId);
}

package com.bookmyturf.repository;

import com.bookmyturf.entity.Slot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface SlotRepository extends JpaRepository<Slot, Long> {
    List<Slot> findByTurfIdAndAvailableTrue(Long turfId);
    List<Slot> findByTurfIdAndSlotDate(Long turfId, LocalDate slotDate);
    List<Slot> findBySlotDateAndAvailableTrue(LocalDate slotDate);
}

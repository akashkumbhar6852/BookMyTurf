package com.bookmyturf.repository;

import com.bookmyturf.entity.Turf;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TurfRepository extends JpaRepository<Turf, Long> {
    List<Turf> findBySportIgnoreCaseAndLocationIgnoreCaseContaining(String sport, String location);
    List<Turf> findByLocationIgnoreCaseContaining(String location);
    List<Turf> findBySportIgnoreCase(String sport);
}

# BookMyTurf — Frontend

A plain HTML/CSS/JavaScript frontend for the BookMyTurf Spring Boot backend.
No build tools, no npm install, no framework — just open it and it talks
straight to your API.

## Visual design
A "matchday ticket booth" identity: pitch-green + floodlight-amber, turf
cards styled like ticket stubs with a punched perforation edge, and a
scoreboard-style display typeface (Big Shoulders Display) for headlines and
match scores, paired with Work Sans for body text.

## 1. Prerequisites
- The BookMyTurf backend (from the other zip) running on `http://localhost:8080`
- Any modern browser
- **Do not open `index.html` by double-clicking it.** Some browsers block
  API requests from `file://` pages. Instead, serve the folder with any
  simple local server — see below.

## 2. Run it

Pick whichever is easiest for you:

**Option A — VS Code "Live Server" extension**
1. Open this `bookmyturf-frontend` folder in VS Code
2. Install the "Live Server" extension if you don't have it
3. Right-click `index.html` → "Open with Live Server"

**Option B — Python (already on most machines)**
```bash
cd bookmyturf-frontend
python -m http.server 5500
```
Then open `http://localhost:5500` in your browser.

**Option C — Node**
```bash
cd bookmyturf-frontend
npx serve .
```

## 3. Point it at a different backend URL (optional)
Open `js/config.js` and change:
```js
const CONFIG = {
  API_BASE_URL: "http://localhost:8080/api",
};
```

## 4. What's included
- **Home** — hero search, featured turfs, "how it works," AI-match teaser
- **Browse turfs** — filter by sport/location, sort by price or rating
- **Turf detail** — description, live slot picker by date, booking, reviews,
  and (if you're logged in as the turf's owner) a quick "add a slot" form
- **Find my match** — hits `POST /api/recommendations` and shows ranked
  results with a scoreboard-style match score
- **Login / Register** — choose "player" or "owner" role on signup
- **My bookings** — list with cancel action
- **List a turf** — owner-only form to create a new turf

## 5. Notes
- Auth token is stored in `localStorage` under `bmt_auth` and sent as
  `Authorization: Bearer <token>` on every authenticated request.
- The backend's `POST /api/recommendations` and `POST/PUT` booking/turf/slot
  endpoints require a logged-in user — the UI will redirect you to Login if
  you try one of those while signed out.
- Everything is vanilla JS with global objects (`Api`, `State`, `Router`,
  `UI`, view modules) loaded as plain `<script>` tags in `index.html` — open
  that file to see the load order if you want to add a new page.
- To add a new page: create `js/views/yourPage.js` following the pattern in
  the existing views, add a `<script>` tag for it in `index.html`, and add a
  route in `js/router.js`.

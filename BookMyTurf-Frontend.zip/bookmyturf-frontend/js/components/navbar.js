const Navbar = (() => {

  function render() {
    State.applyBodyClasses();
    const actions = UI.qs("header-actions");
    const auth = State.get();

    if (!auth) {
      actions.innerHTML = `
        <a href="#/login" class="btn btn-ghost">Log in</a>
        <a href="#/register" class="btn btn-dark">Sign up</a>
      `;
      return;
    }

    actions.innerHTML = `
      <div class="user-chip">
        <span class="avatar">${UI.initials(auth.name)}</span>
        <span>${UI.escapeHtml(auth.name.split(" ")[0])}</span>
      </div>
      <button class="btn btn-ghost" id="logout-btn">Log out</button>
    `;

    UI.qs("logout-btn").addEventListener("click", () => {
      State.clear();
      Toast.info("Logged out.");
      render();
      Router.navigate("/");
    });
  }

  function highlightActive(path) {
    document.querySelectorAll(".main-nav a[data-route]").forEach(a => {
      a.classList.toggle("active", a.getAttribute("data-route") === path);
    });
  }

  return { render, highlightActive };
})();

const UI = (() => {

  function escapeHtml(str) {
    if (str === null || str === undefined) return "";
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function stars(rating) {
    const r = Math.round(rating || 0);
    return "★".repeat(r) + "☆".repeat(5 - r);
  }

  function formatDate(dateStr) {
    if (!dateStr) return "";
    const d = new Date(dateStr + "T00:00:00");
    if (isNaN(d)) return dateStr;
    return d.toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short" });
  }

  function formatTime(t) {
    if (!t) return "";
    const [h, m] = t.split(":");
    const hour = parseInt(h, 10);
    const suffix = hour >= 12 ? "PM" : "AM";
    const hour12 = ((hour + 11) % 12) + 1;
    return `${hour12}:${m} ${suffix}`;
  }

  function loadingRow(label = "Loading…") {
    return `<div class="loading-row"><span class="spinner"></span> ${escapeHtml(label)}</div>`;
  }

  function emptyState({ glyph = "🏟️", title, message, actionHtml = "" }) {
    return `
      <div class="empty-state">
        <div class="glyph">${glyph}</div>
        <h3>${escapeHtml(title)}</h3>
        <p>${escapeHtml(message)}</p>
        ${actionHtml}
      </div>
    `;
  }

  function statusBadge(status) {
    const map = {
      CONFIRMED: "badge-confirmed",
      CANCELLED: "badge-cancelled",
      PENDING: "badge-pending",
      COMPLETED: "badge-completed",
    };
    const cls = map[status] || "badge-pending";
    return `<span class="badge ${cls}">${escapeHtml(status)}</span>`;
  }

  function qs(id) {
    return document.getElementById(id);
  }

  function setContent(html) {
    document.getElementById("app").innerHTML = html;
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  }

  function initials(name) {
    if (!name) return "?";
    return name.trim().split(/\s+/).slice(0, 2).map(w => w[0].toUpperCase()).join("");
  }

  return { escapeHtml, stars, formatDate, formatTime, loadingRow, emptyState, statusBadge, qs, setContent, initials };
})();

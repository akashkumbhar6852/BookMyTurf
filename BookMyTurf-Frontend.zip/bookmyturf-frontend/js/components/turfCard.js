const TurfCard = (() => {
  function render(turf) {
    const rating = turf.rating || 0;
    return `
      <a class="ticket" href="#/turfs/${turf.id}">
        <div class="ticket-main">
          <span class="ticket-sport">${UI.escapeHtml(turf.sport)}</span>
          <div class="ticket-name">${UI.escapeHtml(turf.name)}</div>
          <div class="ticket-loc">📍 ${UI.escapeHtml(turf.location)}</div>
          <div class="ticket-meta">
            <span class="ticket-rating">★ ${rating ? rating.toFixed(1) : "New"}</span>
            <span>·</span>
            <span>Tap to view slots</span>
          </div>
        </div>
        <div class="ticket-stub">
          <div class="price">₹${Math.round(turf.price)}<small>per hour</small></div>
        </div>
      </a>
    `;
  }

  function grid(turfs) {
    if (!turfs.length) {
      return UI.emptyState({
        glyph: "🔍",
        title: "No turfs match that search",
        message: "Try a different sport or location, or clear the filters.",
      });
    }
    return `<div class="turf-grid">${turfs.map(render).join("")}</div>`;
  }

  return { render, grid };
})();

(function () {
  Navbar.render();

  const toggle = document.getElementById("nav-toggle");
  toggle.addEventListener("click", () => {
    document.body.classList.toggle("nav-open");
  });

  Router.init();
})();

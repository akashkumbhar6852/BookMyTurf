// Thin wrapper around fetch() that adds the JWT header and
// normalizes error handling for the whole app.
const Api = (() => {

  async function request(path, { method = "GET", body, auth = true } = {}) {
    const headers = { "Content-Type": "application/json" };
    if (auth && State.token()) {
      headers["Authorization"] = "Bearer " + State.token();
    }

    let res;
    try {
      res = await fetch(CONFIG.API_BASE_URL + path, {
        method,
        headers,
        body: body !== undefined ? JSON.stringify(body) : undefined,
      });
    } catch (networkErr) {
      throw new Error(
        "Can't reach the BookMyTurf API. Is the Spring Boot backend running on " +
        CONFIG.API_BASE_URL + "?"
      );
    }

    if (res.status === 204) return null;

    let data = null;
    try {
      data = await res.json();
    } catch (e) {
      // no JSON body
    }

    if (!res.ok) {
      const message =
        (data && (data.message || (data.errors && Object.values(data.errors)[0]))) ||
        (res.status === 401 ? "Please sign in to continue." : "Something went wrong.");
      const err = new Error(message);
      err.status = res.status;
      throw err;
    }

    return data;
  }

  return {
    get: (path, opts) => request(path, { ...opts, method: "GET" }),
    post: (path, body, opts) => request(path, { ...opts, method: "POST", body }),
    put: (path, body, opts) => request(path, { ...opts, method: "PUT", body }),
    del: (path, opts) => request(path, { ...opts, method: "DELETE" }),
  };
})();

const TurfDetailView = (() => {

  let turf = null;
  let slots = [];
  let selectedSlotId = null;
  let selectedDate = null;

  async function render(turfId) {
    UI.setContent(`<div class="shell section">${UI.loadingRow("Loading turf…")}</div>`);

    try {
      turf = await Api.get(`/turfs/${turfId}`, { auth: false });
    } catch (err) {
      UI.setContent(`<div class="shell section">${UI.emptyState({
        glyph: "🚫", title: "Turf not found", message: err.message,
        actionHtml: `<a href="#/turfs" class="btn btn-dark btn-small">Back to turfs</a>`,
      })}</div>`);
      return;
    }

    selectedDate = todayStr();
    selectedSlotId = null;

    const auth = State.get();
    const isOwnerOfThisTurf = auth && turf.owner && auth.userId === turf.owner.id;

    UI.setContent(`
      <div class="shell section">
        <div class="detail-layout">
          <div>
            <div class="detail-hero">
              <span class="ticket-sport" style="background:rgba(247,245,239,0.15); color:#fff;">${UI.escapeHtml(turf.sport)}</span>
              <h1 class="mt-8">${UI.escapeHtml(turf.name)}</h1>
              <p class="loc">📍 ${UI.escapeHtml(turf.location)} &nbsp;·&nbsp; ★ ${(turf.rating || 0).toFixed(1)} rating</p>
            </div>

            <div class="info-card">
              <h3>About this turf</h3>
              <p class="muted">${UI.escapeHtml(turf.description || "No description provided by the owner yet.")}</p>
            </div>

            ${isOwnerOfThisTurf ? ownerToolsCard() : ""}

            <div class="info-card">
              <div class="flex-between">
                <h3>Reviews</h3>
                <span class="muted">★ ${(turf.rating || 0).toFixed(1)} average</span>
              </div>
              <div id="reviews-list">${UI.loadingRow("Loading reviews…")}</div>
              ${auth ? reviewFormHtml() : `<p class="muted mt-16"><a href="#/login">Log in</a> to leave a review.</p>`}
            </div>
          </div>

          <div class="booking-panel">
            <div class="price-line">₹${Math.round(turf.price)}<small> / hour</small></div>

            <div class="field mt-16">
              <label for="slot-date">Choose a date</label>
              <input type="date" id="slot-date" value="${selectedDate}" min="${todayStr()}" />
            </div>

            <div id="slot-list-wrap">${UI.loadingRow("Loading slots…")}</div>

            <button class="btn btn-primary btn-block" id="book-btn" disabled>Select a slot to continue</button>
          </div>
        </div>
      </div>
    `);

    UI.qs("slot-date").addEventListener("change", (e) => {
      selectedDate = e.target.value;
      selectedSlotId = null;
      loadSlots();
    });

    UI.qs("book-btn").addEventListener("click", handleBook);

    if (isOwnerOfThisTurf) bindOwnerTools();

    loadSlots();
    loadReviews();
    if (auth) bindReviewForm();
  }

  function todayStr() {
    return new Date().toISOString().slice(0, 10);
  }

  async function loadSlots() {
    UI.qs("slot-list-wrap").innerHTML = UI.loadingRow("Loading slots…");
    try {
      slots = await Api.get(`/turfs/${turf.id}/slots?date=${selectedDate}`, { auth: false });
      renderSlots();
    } catch (err) {
      UI.qs("slot-list-wrap").innerHTML = `<p class="field-error">${UI.escapeHtml(err.message)}</p>`;
    }
  }

  function renderSlots() {
    if (!slots.length) {
      UI.qs("slot-list-wrap").innerHTML = UI.emptyState({
        glyph: "🗓️",
        title: "No slots for this date",
        message: "The owner hasn't opened any slots on this day yet. Try another date.",
      });
      updateBookButton();
      return;
    }

    UI.qs("slot-list-wrap").innerHTML = `
      <div class="slot-list">
        ${slots.map(s => `
          <div class="slot-item ${s.available ? "" : "unavailable"} ${selectedSlotId === s.id ? "selected" : ""}"
               data-slot-id="${s.id}" data-available="${s.available}">
            <span>${UI.formatTime(s.startTime)} – ${UI.formatTime(s.endTime)}</span>
            <span>${s.available ? "Open" : "Booked"}</span>
          </div>
        `).join("")}
      </div>
    `;

    document.querySelectorAll(".slot-item").forEach(el => {
      el.addEventListener("click", () => {
        if (el.dataset.available !== "true") return;
        selectedSlotId = Number(el.dataset.slotId);
        renderSlots();
        updateBookButton();
      });
    });

    updateBookButton();
  }

  function updateBookButton() {
    const btn = UI.qs("book-btn");
    if (!btn) return;
    if (selectedSlotId) {
      btn.disabled = false;
      btn.textContent = "Confirm booking →";
    } else {
      btn.disabled = true;
      btn.textContent = "Select a slot to continue";
    }
  }

  async function handleBook() {
    if (!State.isAuthed()) {
      Toast.info("Log in to book a slot.");
      Router.navigate("/login");
      return;
    }
    const btn = UI.qs("book-btn");
    btn.disabled = true;
    btn.textContent = "Booking…";
    try {
      await Api.post("/bookings", { turfId: turf.id, slotId: selectedSlotId });
      Toast.success("Slot booked! See it under My Bookings.");
      selectedSlotId = null;
      await loadSlots();
    } catch (err) {
      Toast.error(err.message);
      updateBookButton();
    }
  }

  async function loadReviews() {
    try {
      const reviews = await Api.get(`/reviews/turf/${turf.id}`, { auth: false });
      UI.qs("reviews-list").innerHTML = reviews.length
        ? reviews.map(r => `
            <div class="review-item">
              <div class="review-top">
                <strong>${UI.escapeHtml(r.user ? r.user.name : "Player")}</strong>
                <span class="stars">${UI.stars(r.rating)}</span>
              </div>
              <p class="muted">${UI.escapeHtml(r.comment || "")}</p>
            </div>
          `).join("")
        : `<p class="muted">No reviews yet — be the first to play and rate this turf.</p>`;
    } catch (err) {
      UI.qs("reviews-list").innerHTML = `<p class="field-error">${UI.escapeHtml(err.message)}</p>`;
    }
  }

  function reviewFormHtml() {
    return `
      <form id="review-form" class="mt-24">
        <div class="field">
          <label for="review-rating">Your rating</label>
          <select id="review-rating">
            <option value="5">★★★★★ Excellent</option>
            <option value="4">★★★★☆ Good</option>
            <option value="3">★★★☆☆ Okay</option>
            <option value="2">★★☆☆☆ Below average</option>
            <option value="1">★☆☆☆☆ Poor</option>
          </select>
        </div>
        <div class="field">
          <label for="review-comment">Your review</label>
          <textarea id="review-comment" placeholder="How was the pitch, lighting, and overall experience?"></textarea>
        </div>
        <button class="btn btn-dark btn-small" type="submit">Post review</button>
      </form>
    `;
  }

  function bindReviewForm() {
    const form = UI.qs("review-form");
    if (!form) return;
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const rating = Number(UI.qs("review-rating").value);
      const comment = UI.qs("review-comment").value.trim();
      try {
        await Api.post("/reviews", { turfId: turf.id, rating, comment });
        Toast.success("Thanks for the review!");
        form.reset();
        loadReviews();
        turf = await Api.get(`/turfs/${turf.id}`, { auth: false });
      } catch (err) {
        Toast.error(err.message);
      }
    });
  }

  function ownerToolsCard() {
    return `
      <div class="info-card">
        <h3>Owner tools</h3>
        <p class="muted mt-8" style="margin-bottom:16px;">Open up a new slot for players to book.</p>
        <form id="add-slot-form">
          <div class="field-row">
            <div class="field">
              <label for="ns-date">Date</label>
              <input type="date" id="ns-date" min="${todayStr()}" required />
            </div>
            <div class="field"></div>
          </div>
          <div class="field-row">
            <div class="field">
              <label for="ns-start">Start time</label>
              <input type="time" id="ns-start" required />
            </div>
            <div class="field">
              <label for="ns-end">End time</label>
              <input type="time" id="ns-end" required />
            </div>
          </div>
          <button class="btn btn-outline btn-small" type="submit">Add slot</button>
        </form>
      </div>
    `;
  }

  function bindOwnerTools() {
    const form = UI.qs("add-slot-form");
    if (!form) return;
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      const slotDate = UI.qs("ns-date").value;
      const startTime = UI.qs("ns-start").value;
      const endTime = UI.qs("ns-end").value;
      try {
        await Api.post(`/turfs/${turf.id}/slots`, { slotDate, startTime, endTime });
        Toast.success("Slot added.");
        form.reset();
        if (slotDate === selectedDate) loadSlots();
      } catch (err) {
        Toast.error(err.message);
      }
    });
  }

  return { render };
})();

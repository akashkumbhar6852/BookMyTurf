const RecommendView = (() => {

  const SPORTS = ["CRICKET", "FOOTBALL", "BADMINTON", "TENNIS", "BASKETBALL", "VOLLEYBALL"];

  async function render() {
    UI.setContent(`
      <div class="shell page-head">
        <h1>Find your match</h1>
        <p>Tell us what you're looking for — sport, budget, and when you want to play — and we'll rank the turfs that fit best.</p>
      </div>

      <div class="shell section-tight">
        <div class="recommend-layout">
          <form class="recommend-form" id="recommend-form">
            <div class="field">
              <label for="r-sport">Sport</label>
              <select id="r-sport" required>
                ${SPORTS.map(s => `<option value="${s}">${cap(s)}</option>`).join("")}
              </select>
            </div>
            <div class="field">
              <label for="r-location">Preferred location</label>
              <input id="r-location" type="text" placeholder="e.g. Nashik" />
            </div>
            <div class="field-row">
              <div class="field">
                <label for="r-budget">Budget (₹/hr)</label>
                <input id="r-budget" type="number" min="0" placeholder="1500" />
              </div>
              <div class="field">
                <label for="r-players">Players</label>
                <input id="r-players" type="number" min="1" placeholder="10" />
              </div>
            </div>
            <div class="field-row">
              <div class="field">
                <label for="r-date">Date</label>
                <input id="r-date" type="date" min="${todayStr()}" />
              </div>
              <div class="field">
                <label for="r-time">Preferred time</label>
                <input id="r-time" type="time" />
              </div>
            </div>
            <button class="btn btn-primary btn-block" type="submit">Find my match →</button>
          </form>

          <div id="recommend-results">
            ${UI.emptyState({
              glyph: "🎯",
              title: "Your matches will show up here",
              message: "Fill in your preferences and we'll rank available turfs by fit — location, budget, rating and slot availability.",
            })}
          </div>
        </div>
      </div>
    `);

    UI.qs("recommend-form").addEventListener("submit", handleSubmit);
  }

  function cap(s) {
    return s.charAt(0) + s.slice(1).toLowerCase();
  }

  function todayStr() {
    return new Date().toISOString().slice(0, 10);
  }

  async function handleSubmit(e) {
    e.preventDefault();

    if (!State.isAuthed()) {
      Toast.info("Log in to get personalized recommendations.");
      Router.navigate("/login");
      return;
    }

    const payload = {
      sport: UI.qs("r-sport").value || null,
      location: UI.qs("r-location").value.trim() || null,
      budget: UI.qs("r-budget").value ? Number(UI.qs("r-budget").value) : null,
      players: UI.qs("r-players").value ? Number(UI.qs("r-players").value) : null,
      date: UI.qs("r-date").value || null,
      preferredTime: UI.qs("r-time").value ? UI.qs("r-time").value + ":00" : null,
    };

    UI.qs("recommend-results").innerHTML = UI.loadingRow("Ranking turfs for you…");

    try {
      const data = await Api.post("/recommendations", payload);
      renderResults(data.recommendations || []);
    } catch (err) {
      UI.qs("recommend-results").innerHTML = UI.emptyState({
        glyph: "⚠️",
        title: "Couldn't get recommendations",
        message: err.message,
      });
    }
  }

  function renderResults(list) {
    if (!list.length) {
      UI.qs("recommend-results").innerHTML = UI.emptyState({
        glyph: "🤷",
        title: "No matches for that combination",
        message: "Try loosening your budget or picking a different date or sport.",
      });
      return;
    }

    UI.qs("recommend-results").innerHTML = `
      <p class="muted" style="margin-bottom:16px;">${list.length} turf${list.length === 1 ? "" : "s"} ranked by fit</p>
      ${list.map(r => `
        <a class="result-card" href="#/turfs/${r.turfId}">
          <div class="score-badge">
            <span class="num">${Math.round(r.matchScore)}</span>
            <span class="lbl">MATCH</span>
          </div>
          <div>
            <h3>${UI.escapeHtml(r.turf)}</h3>
            <p class="reason">${UI.escapeHtml(r.reason)}</p>
          </div>
        </a>
      `).join("")}
    `;
  }

  return { render };
})();

const HomeView = (() => {

  const SPORTS = ["CRICKET", "FOOTBALL", "BADMINTON", "TENNIS", "BASKETBALL", "VOLLEYBALL"];

  async function render() {
    UI.setContent(`
      <section class="hero">
        <div class="shell hero-inner">
          <span class="hero-eyebrow-badge"><span class="dot"></span> Live slots, updated in real time</span>
          <h1>Book your turf.<br/>Before <em>the other team</em> does.</h1>
          <p class="hero-sub">
            Search nearby grounds, see what's actually open tonight, and lock in your slot —
            no calling the owner, no "let me check and get back to you."
          </p>

          <form class="search-ticket" id="hero-search">
            <div class="field">
              <label for="hero-sport">Sport</label>
              <select id="hero-sport">
                <option value="">Any sport</option>
                ${SPORTS.map(s => `<option value="${s}">${cap(s)}</option>`).join("")}
              </select>
            </div>
            <div class="field">
              <label for="hero-location">Location</label>
              <input id="hero-location" type="text" placeholder="e.g. Nashik" />
            </div>
            <button class="btn btn-primary" type="submit">Find turfs →</button>
          </form>

          <div class="hero-stats">
            <div class="hero-stat"><div class="num" id="stat-turfs">–</div><div class="label">Turfs listed</div></div>
            <div class="hero-stat"><div class="num">24/7</div><div class="label">Online booking</div></div>
            <div class="hero-stat"><div class="num">0</div><div class="label">Phone calls needed</div></div>
          </div>
        </div>
      </section>

      <section class="section">
        <div class="shell">
          <div class="section-head">
            <h2>Fresh on BookMyTurf</h2>
            <a href="#/turfs" class="btn btn-outline btn-small">View all turfs</a>
          </div>
          <div id="featured-turfs">${UI.loadingRow("Fetching turfs…")}</div>
        </div>
      </section>

      <section class="section-tight section-alt">
        <div class="shell">
          <div class="section-head">
            <h2>How booking works</h2>
            <p>Three steps, no back-and-forth with the ground owner.</p>
          </div>
          <div class="steps">
            <div class="step">
              <div class="step-index">1</div>
              <h3>Search by sport & location</h3>
              <p>Filter turfs near you by sport, budget and rating in one screen.</p>
            </div>
            <div class="step">
              <div class="step-index">2</div>
              <h3>Pick an open slot</h3>
              <p>See real availability for the exact date and time you want to play.</p>
            </div>
            <div class="step">
              <div class="step-index">3</div>
              <h3>Confirm and play</h3>
              <p>Your slot is locked instantly — manage or cancel it any time from My Bookings.</p>
            </div>
          </div>
        </div>
      </section>

      <section class="section">
        <div class="shell">
          <div class="teaser-band">
            <div>
              <h2>Not sure which turf fits your game?</h2>
              <p>Tell us your sport, budget, and when you want to play — we'll rank the best matches for you.</p>
            </div>
            <a href="#/recommend" class="btn btn-primary">Find my match →</a>
          </div>
        </div>
      </section>
    `);

    UI.qs("hero-search").addEventListener("submit", (e) => {
      e.preventDefault();
      const sport = UI.qs("hero-sport").value;
      const location = UI.qs("hero-location").value.trim();
      const params = new URLSearchParams();
      if (sport) params.set("sport", sport);
      if (location) params.set("location", location);
      Router.navigate("/turfs" + (params.toString() ? "?" + params.toString() : ""));
    });

    loadFeatured();
  }

  function cap(s) {
    return s.charAt(0) + s.slice(1).toLowerCase();
  }

  async function loadFeatured() {
    try {
      const turfs = await Api.get("/turfs", { auth: false });
      UI.qs("stat-turfs").textContent = turfs.length;
      const featured = [...turfs]
        .sort((a, b) => (b.rating || 0) - (a.rating || 0))
        .slice(0, 6);
      UI.qs("featured-turfs").innerHTML = TurfCard.grid(featured.length ? featured : turfs.slice(0, 6));
      if (!turfs.length) {
        UI.qs("featured-turfs").innerHTML = UI.emptyState({
          glyph: "🏟️",
          title: "No turfs listed yet",
          message: "Be the first to list a turf and start taking bookings.",
          actionHtml: `<a href="#/add-turf" class="btn btn-dark btn-small">List a turf</a>`,
        });
      }
    } catch (err) {
      UI.qs("featured-turfs").innerHTML = UI.emptyState({
        glyph: "⚠️",
        title: "Couldn't load turfs",
        message: err.message,
      });
    }
  }

  return { render };
})();

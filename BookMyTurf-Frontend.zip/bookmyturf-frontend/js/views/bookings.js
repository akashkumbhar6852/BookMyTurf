const BookingsView = (() => {

  async function render() {
    if (!State.isAuthed()) {
      Router.navigate("/login");
      return;
    }

    UI.setContent(`
      <div class="shell page-head">
        <h1>My bookings</h1>
        <p>Everything you've booked, confirmed or cancelled, in one place.</p>
      </div>
      <div class="shell section-tight" id="bookings-wrap">
        ${UI.loadingRow("Loading your bookings…")}
      </div>
    `);

    try {
      const bookings = await Api.get("/bookings/my");
      renderList(bookings);
    } catch (err) {
      UI.qs("bookings-wrap").innerHTML = UI.emptyState({
        glyph: "⚠️", title: "Couldn't load bookings", message: err.message,
      });
    }
  }

  function renderList(bookings) {
    if (!bookings.length) {
      UI.qs("bookings-wrap").innerHTML = UI.emptyState({
        glyph: "📭",
        title: "No bookings yet",
        message: "Once you book a slot, it'll show up here.",
        actionHtml: `<a href="#/turfs" class="btn btn-dark btn-small">Browse turfs</a>`,
      });
      return;
    }

    const sorted = [...bookings].sort((a, b) => new Date(b.bookingDate) - new Date(a.bookingDate));

    UI.qs("bookings-wrap").innerHTML = sorted.map(b => `
      <div class="ticket" style="grid-template-columns: 1fr 140px; margin-bottom: 16px;">
        <div class="ticket-main">
          <div class="flex-between">
            <span class="ticket-sport">${UI.escapeHtml(b.turf.sport)}</span>
            ${UI.statusBadge(b.status)}
          </div>
          <div class="ticket-name mt-8">${UI.escapeHtml(b.turf.name)}</div>
          <div class="ticket-loc">📍 ${UI.escapeHtml(b.turf.location)}</div>
          <div class="ticket-meta mt-8">
            <span>🗓️ ${UI.formatDate(b.slot.slotDate)}</span>
            <span>·</span>
            <span>${UI.formatTime(b.slot.startTime)} – ${UI.formatTime(b.slot.endTime)}</span>
          </div>
        </div>
        <div class="ticket-stub" style="justify-content:space-between; padding: 16px 0;">
          <div class="price" style="font-size:18px;">₹${Math.round(b.turf.price)}</div>
          ${b.status === "CONFIRMED"
            ? `<button class="btn btn-small" style="background:transparent;border:1.5px solid rgba(247,245,239,0.5);color:#fff;" data-cancel="${b.id}">Cancel</button>`
            : `<span style="font-size:12px; opacity:0.7;">No actions</span>`}
        </div>
      </div>
    `).join("");

    document.querySelectorAll("[data-cancel]").forEach(btn => {
      btn.addEventListener("click", () => handleCancel(btn.dataset.cancel));
    });
  }

  async function handleCancel(id) {
    if (!confirm("Cancel this booking? The slot will be freed up for someone else.")) return;
    try {
      await Api.put(`/bookings/${id}/cancel`);
      Toast.success("Booking cancelled.");
      render();
    } catch (err) {
      Toast.error(err.message);
    }
  }

  return { render };
})();

const AddTurfView = (() => {

  const SPORTS = ["CRICKET", "FOOTBALL", "BADMINTON", "TENNIS", "BASKETBALL", "VOLLEYBALL"];

  async function render() {
    if (!State.isAuthed()) {
      Toast.info("Log in as a turf owner to list a turf.");
      Router.navigate("/login");
      return;
    }
    if (!State.isOwner()) {
      UI.setContent(`
        <div class="shell section">
          ${UI.emptyState({
            glyph: "🔒",
            title: "Owner account required",
            message: "Your account is registered as a player. Create a new account with the \"I own a turf\" option to list a ground.",
            actionHtml: `<a href="#/register" class="btn btn-dark btn-small">Create owner account</a>`,
          })}
        </div>
      `);
      return;
    }

    UI.setContent(`
      <div class="shell page-head">
        <h1>List your turf</h1>
        <p>Add your ground's details. You can open up bookable slots from the turf's page once it's listed.</p>
      </div>

      <div class="shell section-tight">
        <div class="auth-card" style="max-width:560px; margin:0;">
          <form id="add-turf-form">
            <div class="field">
              <label for="t-name">Turf name</label>
              <input id="t-name" type="text" required placeholder="e.g. Green Arena" />
            </div>
            <div class="field-row">
              <div class="field">
                <label for="t-sport">Sport</label>
                <select id="t-sport" required>
                  ${SPORTS.map(s => `<option value="${s}">${cap(s)}</option>`).join("")}
                </select>
              </div>
              <div class="field">
                <label for="t-price">Price (₹/hour)</label>
                <input id="t-price" type="number" min="1" step="1" required placeholder="1200" />
              </div>
            </div>
            <div class="field">
              <label for="t-location">Location</label>
              <input id="t-location" type="text" required placeholder="e.g. Nashik" />
            </div>
            <div class="field">
              <label for="t-description">Description</label>
              <textarea id="t-description" placeholder="Ground size, surface type, floodlights, parking, etc."></textarea>
            </div>
            <button class="btn btn-primary btn-block" type="submit">List this turf</button>
          </form>
        </div>
      </div>
    `);

    UI.qs("add-turf-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = e.target.querySelector("button");
      btn.disabled = true; btn.textContent = "Listing…";
      try {
        const turf = await Api.post("/turfs", {
          name: UI.qs("t-name").value.trim(),
          sport: UI.qs("t-sport").value,
          price: Number(UI.qs("t-price").value),
          location: UI.qs("t-location").value.trim(),
          description: UI.qs("t-description").value.trim(),
        });
        Toast.success("Turf listed! Now add some slots.");
        Router.navigate("/turfs/" + turf.id);
      } catch (err) {
        Toast.error(err.message);
        btn.disabled = false; btn.textContent = "List this turf";
      }
    });
  }

  function cap(s) {
    return s.charAt(0) + s.slice(1).toLowerCase();
  }

  return { render };
})();

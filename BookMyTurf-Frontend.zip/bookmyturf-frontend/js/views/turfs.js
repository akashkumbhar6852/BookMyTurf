const TurfsView = (() => {

  const SPORTS = ["CRICKET", "FOOTBALL", "BADMINTON", "TENNIS", "BASKETBALL", "VOLLEYBALL"];
  let allTurfs = [];

  async function render(query) {
    const params = new URLSearchParams(query || "");
    const initialSport = params.get("sport") || "";
    const initialLocation = params.get("location") || "";

    UI.setContent(`
      <div class="shell page-head">
        <h1>Browse turfs</h1>
        <p>Filter by sport, location or price to find a ground that fits your game and budget.</p>
      </div>

      <div class="shell section-tight">
        <form class="filter-bar" id="filter-form">
          <div class="field grow">
            <label for="f-location">Location</label>
            <input id="f-location" type="text" placeholder="Search by area or city" value="${UI.escapeHtml(initialLocation)}" />
          </div>
          <div class="field">
            <label for="f-sport">Sport</label>
            <select id="f-sport">
              <option value="">Any sport</option>
              ${SPORTS.map(s => `<option value="${s}" ${s === initialSport ? "selected" : ""}>${cap(s)}</option>`).join("")}
            </select>
          </div>
          <div class="field">
            <label for="f-sort">Sort by</label>
            <select id="f-sort">
              <option value="rating">Top rated</option>
              <option value="price-asc">Price: low to high</option>
              <option value="price-desc">Price: high to low</option>
            </select>
          </div>
          <button class="btn btn-dark" type="submit">Apply filters</button>
        </form>

        <div id="turf-results">${UI.loadingRow("Loading turfs…")}</div>
      </div>
    `);

    UI.qs("filter-form").addEventListener("submit", (e) => {
      e.preventDefault();
      applyFilters();
    });

    await loadTurfs(initialSport, initialLocation);
  }

  function cap(s) {
    return s.charAt(0) + s.slice(1).toLowerCase();
  }

  async function loadTurfs(sport, location) {
    try {
      const search = new URLSearchParams();
      if (sport) search.set("sport", sport);
      if (location) search.set("location", location);
      const path = "/turfs" + (search.toString() ? "?" + search.toString() : "");
      allTurfs = await Api.get(path, { auth: false });
      renderResults();
    } catch (err) {
      UI.qs("turf-results").innerHTML = UI.emptyState({
        glyph: "⚠️",
        title: "Couldn't load turfs",
        message: err.message,
      });
    }
  }

  function renderResults() {
    const sort = UI.qs("f-sort") ? UI.qs("f-sort").value : "rating";
    let list = [...allTurfs];
    if (sort === "price-asc") list.sort((a, b) => a.price - b.price);
    else if (sort === "price-desc") list.sort((a, b) => b.price - a.price);
    else list.sort((a, b) => (b.rating || 0) - (a.rating || 0));

    UI.qs("turf-results").innerHTML = `
      <p class="muted mt-8" style="margin-bottom:18px;">${list.length} turf${list.length === 1 ? "" : "s"} found</p>
      ${TurfCard.grid(list)}
    `;
  }

  function applyFilters() {
    loadTurfs(UI.qs("f-sport").value, UI.qs("f-location").value.trim());
  }

  return { render };
})();

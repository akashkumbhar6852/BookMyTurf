const AuthView = (() => {

  function renderLogin() {
    UI.setContent(`
      <div class="auth-shell">
        <div class="auth-card">
          <h1>Welcome back</h1>
          <p class="sub">Log in to book slots, leave reviews, and manage your turfs.</p>
          <form id="login-form">
            <div class="field">
              <label for="l-email">Email</label>
              <input id="l-email" type="email" required autocomplete="email" />
            </div>
            <div class="field">
              <label for="l-password">Password</label>
              <input id="l-password" type="password" required autocomplete="current-password" />
            </div>
            <button class="btn btn-primary btn-block" type="submit">Log in</button>
          </form>
          <p class="auth-switch">New here? <a href="#/register">Create an account</a></p>
        </div>
      </div>
    `);

    UI.qs("login-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = e.target.querySelector("button");
      btn.disabled = true; btn.textContent = "Logging in…";
      try {
        const data = await Api.post("/auth/login", {
          email: UI.qs("l-email").value.trim(),
          password: UI.qs("l-password").value,
        }, { auth: false });
        State.set(data);
        Navbar.render();
        Toast.success(`Welcome back, ${data.name.split(" ")[0]}!`);
        Router.navigate("/");
      } catch (err) {
        Toast.error(err.message);
        btn.disabled = false; btn.textContent = "Log in";
      }
    });
  }

  function renderRegister() {
    UI.setContent(`
      <div class="auth-shell">
        <div class="auth-card">
          <h1>Create your account</h1>
          <p class="sub">Book as a player, or list your ground as an owner.</p>
          <form id="register-form">
            <div class="role-toggle">
              <label><input type="radio" name="role" value="USER" checked /><span>I want to book turfs</span></label>
              <label><input type="radio" name="role" value="OWNER" /><span>I own a turf</span></label>
            </div>
            <div class="field">
              <label for="r-name">Full name</label>
              <input id="r-name" type="text" required autocomplete="name" />
            </div>
            <div class="field">
              <label for="r-email">Email</label>
              <input id="r-email" type="email" required autocomplete="email" />
            </div>
            <div class="field">
              <label for="r-password">Password</label>
              <input id="r-password" type="password" required minlength="6" autocomplete="new-password" />
            </div>
            <div class="field-hint">At least 6 characters.</div>
            <button class="btn btn-primary btn-block" type="submit">Create account</button>
          </form>
          <p class="auth-switch">Already have an account? <a href="#/login">Log in</a></p>
        </div>
      </div>
    `);

    UI.qs("register-form").addEventListener("submit", async (e) => {
      e.preventDefault();
      const btn = e.target.querySelector("button");
      btn.disabled = true; btn.textContent = "Creating account…";
      const role = e.target.querySelector('input[name="role"]:checked').value;
      try {
        const data = await Api.post("/auth/register", {
          name: UI.qs("r-name").value.trim(),
          email: UI.qs("r-email").value.trim(),
          password: UI.qs("r-password").value,
          role,
        }, { auth: false });
        State.set(data);
        Navbar.render();
        Toast.success(`Welcome to BookMyTurf, ${data.name.split(" ")[0]}!`);
        Router.navigate(role === "OWNER" ? "/add-turf" : "/turfs");
      } catch (err) {
        Toast.error(err.message);
        btn.disabled = false; btn.textContent = "Create account";
      }
    });
  }

  return { renderLogin, renderRegister };
})();

// Tiny auth-state store backed by localStorage.
const State = (() => {
  const KEY = "bmt_auth";

  function get() {
    try {
      const raw = localStorage.getItem(KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function set(auth) {
    localStorage.setItem(KEY, JSON.stringify(auth));
    applyBodyClasses();
  }

  function clear() {
    localStorage.removeItem(KEY);
    applyBodyClasses();
  }

  function isAuthed() {
    return !!get();
  }

  function isOwner() {
    const a = get();
    return !!a && a.role === "OWNER";
  }

  function token() {
    const a = get();
    return a ? a.token : null;
  }

  function applyBodyClasses() {
    document.body.classList.toggle("is-authed", isAuthed());
    document.body.classList.toggle("is-owner", isOwner());
  }

  return { get, set, clear, isAuthed, isOwner, token, applyBodyClasses };
})();

const Router = (() => {

  function navigate(path) {
    window.location.hash = "#" + path;
  }

  function parseHash() {
    const hash = window.location.hash.replace(/^#/, "") || "/";
    const [path, query] = hash.split("?");
    return { path: path || "/", query: query || "" };
  }

  async function resolve() {
    const { path, query } = parseHash();
    closeMobileNav();

    // /turfs/123 -> turf detail
    const turfDetailMatch = path.match(/^\/turfs\/(\d+)$/);

    if (path === "/" || path === "") {
      Navbar.highlightActive("/");
      await HomeView.render();
    } else if (path === "/turfs") {
      Navbar.highlightActive("/turfs");
      await TurfsView.render(query);
    } else if (turfDetailMatch) {
      Navbar.highlightActive("/turfs");
      await TurfDetailView.render(turfDetailMatch[1]);
    } else if (path === "/recommend") {
      Navbar.highlightActive("/recommend");
      await RecommendView.render();
    } else if (path === "/login") {
      Navbar.highlightActive("");
      AuthView.renderLogin();
    } else if (path === "/register") {
      Navbar.highlightActive("");
      AuthView.renderRegister();
    } else if (path === "/bookings") {
      Navbar.highlightActive("/bookings");
      await BookingsView.render();
    } else if (path === "/add-turf") {
      Navbar.highlightActive("/add-turf");
      await AddTurfView.render();
    } else {
      renderNotFound();
    }
  }

  function renderNotFound() {
    UI.setContent(`
      <div class="shell section">
        ${UI.emptyState({
          glyph: "🧭",
          title: "Page not found",
          message: "That page doesn't exist — let's get you back on track.",
          actionHtml: `<a href="#/" class="btn btn-dark btn-small">Back home</a>`,
        })}
      </div>
    `);
  }

  function closeMobileNav() {
    document.body.classList.remove("nav-open");
  }

  function init() {
    window.addEventListener("hashchange", resolve);
    resolve();
  }

  return { navigate, init };
})();

// Change this if your backend runs somewhere other than localhost:8080
const CONFIG = {
  API_BASE_URL: "http://localhost:8080/api",
};
